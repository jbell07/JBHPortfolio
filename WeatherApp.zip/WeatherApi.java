package com.weatherapp.weather_backend;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONObject;
import org.json.JSONArray;

public class WeatherApi {
	private static final String API_KEY = "af85ae99171d409a94420641252602";
	// this is the URL from our weather API
	private static final String BASE_URL = "http://api.weatherapi.com/v1/current.json?key=";
	// the forecast URL
	private static final String week_Forecast_URL = "http://api.weatherapi.com/v1/forecast.json?key=";

	/**
	 * Grabs weather data from a location given by the user
	 * 
	 * @param location
	 * @return weather data object containing weather data
	 */
	public static WeatherData getWeather(String location) {
		try {
			// Make sure spaces are handled
			String encodedLocation = URLEncoder.encode(location, "UTF-8");
			// full path for the api
			String urlString = BASE_URL + API_KEY + "&q=" + encodedLocation;
			// make the url object for the api to use
			URL url = new URL(urlString);
			// connect to the weather api
			HttpURLConnection apiConnection = (HttpURLConnection) url.openConnection();
			// set the request to the API to get
			apiConnection.setRequestMethod("GET");
			// 200 OK = successful data return 400 = bad request 401 = unauthorized(api key
			// missing)
			if (apiConnection.getResponseCode() != 200) {
				System.out.println("Error fetching weather: " + apiConnection.getResponseCode() + " "
						+ apiConnection.getResponseMessage());
				// if api failed return
				return null;
			}

			BufferedReader in = new BufferedReader(new InputStreamReader(apiConnection.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();

			// read the return response from the API line by line
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			// convert the current response into a JSON object
			JSONObject jsonResponse = new JSONObject(response.toString());
			JSONObject current = jsonResponse.getJSONObject("current");
			JSONObject condition = current.getJSONObject("condition");

			return new WeatherData(jsonResponse.getJSONObject("location").getString("localtime"),
					current.getInt("temp_c"), current.getInt("temp_f"), current.getInt("humidity"),
					current.getInt("wind_mph"), current.getInt("wind_kph"), current.getString("wind_dir"),
					current.getInt("feelslike_c"), current.getInt("feelslike_f"), current.getInt("uv"),
					condition.getString("text"), condition.getString("icon"),
					current.has("chance_of_rain") ? current.getInt("chance_of_rain") : 0, "N/A", // Placeholder for
																									// sunrise
					"N/A" // Placeholder for sunset
			);

		} catch (Exception e) {
			System.out.println("Error fetching weather: " + e.getMessage());
			return null;
		}
	}

	public static String getWeekForecast(String location) {
		try {
			// Encoded location using UTF-8
			String encodedLocation = URLEncoder.encode(location, "UTF-8");
			String urlString = week_Forecast_URL + API_KEY + "&q=" + encodedLocation + "&days=7";
			URL url = new URL(urlString);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			// first check the connection to the API
			if (conn.getResponseCode() != 200) {
				return "Error fetching weather: " + conn.getResponseCode() + " " + conn.getResponseMessage();
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuilder forecastResponse = new StringBuilder();

			while ((inputLine = in.readLine()) != null) {
				forecastResponse.append(inputLine);
			}
			in.close();

			JSONObject jsonResponse = new JSONObject(forecastResponse.toString());
			JSONArray forecastDays = jsonResponse.getJSONObject("forecast").getJSONArray("forecastday");

			StringBuilder weeklyForecast = new StringBuilder();
			for (int i = 0; i < forecastDays.length(); i++) {
				JSONObject weekDay = forecastDays.getJSONObject(i);
				String date = weekDay.getString("date");
				String dayOfWeek = getWeekday(date);
				int maxTempF = weekDay.getJSONObject("day").getInt("maxtemp_f");
				int minTempF = weekDay.getJSONObject("day").getInt("mintemp_f");
				String condition = weekDay.getJSONObject("day").getJSONObject("condition").getString("text");

				weeklyForecast.append(dayOfWeek).append(" (").append(date).append("): ").append(minTempF)
						.append("°F - ").append(maxTempF).append("°F, ").append(condition).append(" | ");
			}

			return weeklyForecast.toString();
		} catch (Exception e) {
			return "Error fetching week's forecast: " + e.getMessage();
		}
	}

	private static String getWeekday(String date) {
		try {
			java.time.LocalDate localDate = java.time.LocalDate.parse(date);
			return localDate.getDayOfWeek().toString(); // Example: "MONDAY"
		}

		catch (Exception e) {
			return "There was an error somewhere along the way";
		}
	}
	// Planning on adding more in iteration 2
}