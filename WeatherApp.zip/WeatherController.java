package com.weatherapp.weather_backend;

import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {

    private final WeatherApi weatherApi = new WeatherApi();

    @GetMapping
    public WeatherData getCurrentWeather(@RequestParam String city) {
        return weatherApi.getWeather(city);
    }

    @GetMapping("/forecast")
    public String getWeeklyForecast(@RequestParam String city) {
        return weatherApi.getWeekForecast(city);
    }
    @GetMapping("/test")
    public String test() {
        return "Backend is alive!";
    }
    @GetMapping("/suggest") 
        public List<String> suggestCities(@RequestParam String query) {
        return CitySearchApi.getCitySuggestions(query);
    }
}